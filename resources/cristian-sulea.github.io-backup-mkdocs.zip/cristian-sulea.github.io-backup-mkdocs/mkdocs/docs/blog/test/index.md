Cupcake indexer is a snazzy new project for indexing small cakes.

![Screenshot](screenshot.png)

*Above: Cupcake indexer in progress*